---
title: alloydb-get-user
type: docs
weight: 1
description: "The \"alloydb-get-user\" tool retrieves details for a specific AlloyDB user.\n"
---

## About

The `alloydb-get-user` tool retrieves detailed information for a single,
specified AlloyDB user.

| Parameter  | Type   | Description                                        | Required |
| :--------- | :----- | :------------------------------------------------- | :------- |
| `project`  | string | The GCP project ID to get user for.                | Yes      |
| `location` | string | The location of the cluster (e.g., 'us-central1'). | Yes      |
| `cluster`  | string | The ID of the cluster to retrieve the user from.   | Yes      |
| `user`     | string | The ID of the user to retrieve.                    | Yes      |


## Compatible Sources

{{< compatible-sources >}}

## Example

```yaml
kind: tool
name: get_specific_user
type: alloydb-get-user
source: my-alloydb-admin-source
description: Use this tool to retrieve details for a specific AlloyDB user.
```

## Reference

| **field**   | **type** | **required** | **description**                                      |
| ----------- | :------: | :----------: | ---------------------------------------------------- |
| type        |  string  |     true     | Must be alloydb-get-user.                            |
| source      |  string  |     true     | The name of an `alloydb-admin` source.               |
| description |  string  |     false    | Description of the tool that is passed to the agent. |