---
title: "cloud-healthcare-get-fhir-store-metrics"
type: docs
weight: 1
description: >
  A "cloud-healthcare-get-fhir-store-metrics" tool retrieves metrics for a FHIR store.
---

## About

A `cloud-healthcare-get-fhir-store-metrics` tool retrieves metrics for a FHIR store.

`cloud-healthcare-get-fhir-store-metrics` returns the metrics of a FHIR store.


## Compatible Sources

{{< compatible-sources >}}

## Example

```yaml
kind: tool
name: get_fhir_store_metrics
type: cloud-healthcare-get-fhir-store-metrics
source: my-healthcare-source
description: Use this tool to get metrics for a FHIR store.
```

## Reference

| **field**   | **type** | **required** | **description**                                    |
|-------------|:--------:|:------------:|----------------------------------------------------|
| type        |  string  |     true     | Must be "cloud-healthcare-get-fhir-store-metrics". |
| source      |  string  |     true     | Name of the healthcare source.                     |
| description |  string  |     true     | Description of the tool that is passed to the LLM. |

### Parameters

| **field** | **type** | **required** | **description**                       |
|-----------|:--------:|:------------:|---------------------------------------|
| storeID   |  string  |    true*     | The FHIR store ID to get metrics for. |

*If the `allowedFHIRStores` in the source has length 1, then the `storeID` parameter is not needed.
